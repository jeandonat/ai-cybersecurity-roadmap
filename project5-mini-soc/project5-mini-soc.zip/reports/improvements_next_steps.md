# Next Steps

1. Add Suricata IDS
2. Add OpenVAS automation
3. Create custom correlation rules
