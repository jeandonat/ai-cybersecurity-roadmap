# Mini SOC Summary

Functional SOC with Wazuh Manager and Kali Agent.
SSH brute-force and FIM detection validated.
